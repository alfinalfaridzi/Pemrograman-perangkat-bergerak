package com.example.daftarmenu;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<com.example.daftarmenu.SetterGetter> datamenu;
    GridLayoutManager gridLayoutManager;
     com.example.daftarmenu.DashBoardActivity adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);

        addData();
        gridLayoutManager = new GridLayoutManager(this,1);
        recyclerView.setLayoutManager(gridLayoutManager);

        adapter = new com.example.daftarmenu.DashBoardActivity(datamenu);
        recyclerView.setAdapter(adapter);
    }

    public void addData(){
        datamenu = new ArrayList<>();
        datamenu.add(new com.example.daftarmenu.SetterGetter("Sate","FotoMakanan1","Rp.40.000","Sate Sapi","Harga:   Rp.40.000",R.drawable.sate));
        datamenu.add(new com.example.daftarmenu.SetterGetter("Soto","FotoMakanan2","Rp.20.000","Soto ","Harga:   Rp.20.000",R.drawable.soto));
        datamenu.add(new com.example.daftarmenu.SetterGetter("Geprek","FotoMakanan3","Rp.15.000","Geprek","Harga   Rp.15.000",R.drawable.geprek));
        datamenu.add(new com.example.daftarmenu.SetterGetter("AyamGoreng","FotoMakanan1","Rp.10.000","AyamGoreng","Harga:   Rp.10.000",R.drawable.ayamgoreng));
        datamenu.add(new com.example.daftarmenu.SetterGetter("Seblak","FotoMakanan2","Rp.15.000","Seblak ","Harga:   Rp.15.000",R.drawable.seblak));
        datamenu.add(new com.example.daftarmenu.SetterGetter("EsDurian","FotoMakanan3","Rp.8.000","EsDurian","Harga   Rp.8.000",R.drawable.esdurian));
        datamenu.add(new com.example.daftarmenu.SetterGetter("EsTeler","FotoMakanan3","Rp.7.000","EsTeler","Harga   Rp.7.000",R.drawable.esteler));
    }
}