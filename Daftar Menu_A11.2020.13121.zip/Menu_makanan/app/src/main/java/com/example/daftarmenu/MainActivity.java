package com.example.daftarmenu;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<com.example.daftarmenu.SetterGetter> datamenu;
    GridLayoutManager gridLayoutManager;
     com.example.daftarmenu.DashBoardActivity adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);

        addData();
        gridLayoutManager = new GridLayoutManager(this,1);
        recyclerView.setLayoutManager(gridLayoutManager);

        adapter = new com.example.daftarmenu.DashBoardActivity(datamenu);
        recyclerView.setAdapter(adapter);
    }

    public void addData(){
        datamenu = new ArrayList<>();
        datamenu.add(new com.example.daftarmenu.SetterGetter("Sate","FotoMakanan1","Rp.40.000","Sate Sapi","Harga:   Rp.40.000",R.drawable.sate));
        datamenu.add(new com.example.daftarmenu.SetterGetter("Soto","FotoMakanan2","Rp.20.000","Soto ","Harga:   Rp.20.000",R.drawable.soto));
        datamenu.add(new com.example.daftarmenu.SetterGetter("Geprek","FotoMakanan3","Rp.15.000","Geprek","Harga   Rp.15.000",R.drawable.geprek));
    }
}